----------
README.txt
----------
The following files are example files to be used for Aggregate Data Uploads.
The example is Census data from Malawi.
The column headings are server-instance specific, but these example files are based off of 
the default configuration for an English language instance.

Metadata:
- AggregateData-MetadataExample-MW_Census.csv

Disaggregations:
- AggregateData-DisaggregationsExample-MW_Census.csv

Data:
- AggregateData-DataExample-MW_Census.csv
