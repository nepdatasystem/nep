var contextPath = "";

$.getJSON(contextPath + "/api/me.json", function( data ) {
	console.debug("data", data);
	var user = data.userCredentials.code;
	console.debug("user", user);
	
	var referer = document.referrer;
	console.debug("referer", referer);
	
	$('#user').val(user);
	$('#referer').val(referer);
	$('#nepForm').submit();
});